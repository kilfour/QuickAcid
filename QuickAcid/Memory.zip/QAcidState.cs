﻿namespace QuickAcid
{
    public class QAcidState
    {
        public QAcidRunner<Acid> Runner { get; private set; }

        public int RunNumber { get; private set; }
        public List<int> Runs { get; private set; }

        public Memory Memory { get; private set; }
        public SimpleMemory GlobalMemory { get; private set; }
        public SimpleMemory TempMemory { get; private set; }

        public bool Shrinking { get; private set; }
        public Memory Shrunk { get; private set; }

        public bool Verifying { get; private set; }

        public bool Reporting { get; private set; }

        public string FailingSpec { get; private set; }
        public bool Failed { get; private set; }
        public Exception Exception { get; private set; }

        private QAcidReport report = new QAcidReport();
        private int shrinkCount = 0;
        public QAcidState(QAcidRunner<Acid> runner)
        {
            Runner = runner;
            Runs = new List<int>();
            Memory = new Memory(this);
            GlobalMemory = new SimpleMemory();
            TempMemory = new SimpleMemory();
            Shrunk = new Memory(this);
        }

        public void Run(int times)
        {
            for (int j = 0; j < times; j++)
            {
                Run();
                if (Failed)
                    return;
            }
        }

        public void Run()
        {
            Runs.Add(RunNumber);
            Runner(this);
            if (Failed)
            {
                HandleFailure();
                return;
            }
            RunNumber++;
        }

        public bool ShrinkRun(object key, object value)
        {
            Verifying = true;
            Shrinking = false;
            Reporting = false;
            var tempMemory = TempMemory;
            Failed = false;
            TempMemory = new SimpleMemory();

            var failingSpec = FailingSpec;
            var exception = Exception;
            var runNumber = RunNumber;
            var oldVal = Memory.Get<object>(key);
            Memory.Set(key, value);
            foreach (var run in Runs)
            {
                RunNumber = run;
                Runner(this);
            }

            var failed = Failed;
            RunNumber = runNumber;
            Failed = false;
            FailingSpec = failingSpec;
            Exception = exception;

            Verifying = false;
            Shrinking = true;

            Memory.Set(key, oldVal);
            TempMemory = tempMemory;

            return failed;
        }

        public bool IsNormalRun()
        {
            return (Verifying == false && Shrinking == false && Reporting == false);
        }

        public void FailedWithException(Exception exception)
        {
            if (Verifying)
            {
                if (Exception == null)
                {
                    BreakRun = true;
                    Failed = true;
                    return;
                }

                if (Exception.GetType() != exception.GetType())
                {
                    BreakRun = true;
                    Failed = true;
                    return;
                }
            }
            Failed = true;
            Exception = exception;
        }

        public void SpecFailed(string failingSpec)
        {
            Failed = true;
            FailingSpec = failingSpec;
        }

        public void LogReport(QAcidReportEntry reportEntry)
        {
            report.AddEntry(reportEntry);
        }

        private void HandleFailure()
        {
            ShrinkActions();
            ShrinkInputs();
            Report();
        }

        public bool BreakRun { get; private set; }

        private void ShrinkActions()
        {
            Verifying = true;
            Shrinking = false;
            Reporting = false;
            BreakRun = false;

            Failed = false;
            var failingSpec = FailingSpec;
            var exception = Exception;

            var max = Runs.Max();
            var current = 0;

            while (current <= max)
            {
                Failed = false;
                TempMemory = new SimpleMemory();
                FailingSpec = failingSpec;
                Exception = exception;

                foreach (var run in Runs.ToList())
                {
                    RunNumber = run;
                    if (run != current)
                        Runner(this);
                    if (BreakRun)
                        break;
                }
                if (Failed && !BreakRun)
                {
                    Runs.Remove(current);
                }
                current++;
                shrinkCount++;
            }

            Failed = true;
            FailingSpec = failingSpec;
            Exception = exception;
        }

        public string ShrinkSummary =>
            $"Falsified after {Runs.Count} runs, {shrinkCount} shrinks";

        private void ShrinkInputs()
        {
            Verifying = false;
            Shrinking = true;
            Reporting = false;

            Failed = false;
            TempMemory = new SimpleMemory();

            var failingSpec = FailingSpec;
            var exception = Exception;

            // 🚑 Fallback: pull from TempMemory instead of Memory (if Memory is empty)
            var allInputs = TempMemory.GetAll();
            var currentValues = allInputs.ToDictionary(
                entry => entry.Key,
                entry => entry.Value
            );

            foreach (var key in currentValues.Keys.ToList())
            {
                var originalValue = currentValues[key];
                var shrinkCandidates = Shrink.Input(originalValue);

                foreach (var candidate in shrinkCandidates)
                {
                    var trialInputs = new Dictionary<string, object>(currentValues);
                    trialInputs[key] = candidate;

                    // Re-run the test with modified input
                    TempMemory = new SimpleMemory();
                    foreach (var pair in trialInputs)
                    {
                        TempMemory.AddShrinkableInput(pair.Key, pair.Value);
                    }

                    Failed = false;
                    RunNumber = Runs.First();
                    Runner(this);
                    shrinkCount++;

                    if (Failed)
                    {
                        // Shrink was valid — keep the candidate
                        currentValues[key] = candidate;
                        break; // Try next input
                    }
                }
            }

            // Store final shrunk values in TempMemory for report
            TempMemory = new SimpleMemory();
            foreach (var pair in currentValues)
            {
                TempMemory.AddShrinkableInput(pair.Key, pair.Value);

                // 🔍 Store a readable summary for report output
                var summary = Shrink.Summarize(pair.Value);
                Shrunk.Set(pair.Key, summary);
            }

            Failed = true;
            FailingSpec = failingSpec;
            Exception = exception;
        }


        private void Report()
        {
            report = new QAcidReport();
            report.ShrinkAttempts = shrinkCount;
            TempMemory = new SimpleMemory();
            Verifying = false;
            Shrinking = false;
            Reporting = true;

            Failed = false;
            var failingSpec = FailingSpec;
            var exception = Exception;

            foreach (var run in Runs.ToList())
            {
                RunNumber = run;
                Runner(this);
            }

            // ✅ Finalize report input entries from Shrunk
            foreach (var pair in Shrunk.GetAll())
            {
                Console.WriteLine($"REPORTING INPUT: {pair.Key} = {pair.Value ?? "null"}");
                report.Inputs.Add(new QAcidReportInputEntry(pair.Key)
                {
                    Value = pair.Value
                });
            }

            Failed = true;
            FailingSpec = failingSpec;
            Exception = exception;

            if (Exception != null)
            {
                throw new FalsifiableException(ShrinkSummary + "\n" + report.ToString(), exception)
                {
                    QAcidReport = report
                };
            }

            throw new FalsifiableException(ShrinkSummary + "\n" + report.ToString())
            {
                QAcidReport = report
            };
        }
    }
}